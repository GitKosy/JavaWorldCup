import javax.swing.*;
import java.awt.*;

public class EntryPanel extends JPanel {

	private Point pt;
	private JLabel normal;
	private int velocity;
	private JLabel nameLabel;
	public EntryPanel() {
		setLayout(null);
		setBackground(Color.black);
		nameLabel = new JLabel();
		velocity =0;
		
		nameLabel.setFont(new Font("",Font.BOLD,30));
		nameLabel.setSize(700,50);
		nameLabel.setLocation(this.getWidth()/2-nameLabel.getWidth()/2,600);
		nameLabel.setHorizontalAlignment(JLabel.CENTER);
		nameLabel.setForeground(Color.orange);
		nameLabel.setOpaque(true);
		nameLabel.setBackground(Color.blue);
		this.add(nameLabel);
	}
	public EntryPanel(int x,int y) {
		pt = new Point();
		pt.x=x;
		pt.y = y;
		this.setLayout(null);
		this.setBounds(pt.x, pt.y, 700, 800);
		setBackground(Color.black);
		velocity=1;
		
		nameLabel.setFont(new Font("",Font.BOLD,30));
		nameLabel.setSize(700,50);
		nameLabel.setLocation(this.getWidth()/2-nameLabel.getWidth()/2,600);
		nameLabel.setHorizontalAlignment(JLabel.CENTER);
		nameLabel.setForeground(Color.orange);
		nameLabel.setOpaque(true);
		nameLabel.setBackground(Color.blue);
		this.add(nameLabel);
	}
	
	public int getVelocity() {
		return this.velocity;
	}
	
	public void setVeloctiy(int velocity) {
		this.velocity = velocity;
	}
	
	public int getPtX() {
		return this.pt.x;
	}
	
	public void setPtX(int x) {
		this.pt.x=x;
	}
	
	public int getPtY() {
		return this.pt.y;
	}
	public void setPtY(int y) {
		this.pt.y=y;
	}
	
	public Point getPt() {
		return this.pt;
	}
	
	public void setSizeofElement() {
		nameLabel.setVisible(false);
	}
	
	public void setReturnSize() {
		nameLabel.setVisible(true);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
