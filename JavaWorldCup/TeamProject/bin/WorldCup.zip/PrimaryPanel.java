import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class PrimaryPanel extends JPanel {

	private InitPanel		P_Init;
	private MainGamePanel 	P_MainGame;
	private EndingPanel		P_Ending;
	private ExplainPanel	P_Explain;
	
	private String nSex;
	private String nRank;
	public PrimaryPanel() {
		this.setBackground(Color.black);
		this.setBounds(0, 0, 1440, 900);
		this.setPreferredSize(new Dimension(1440,900));
		this.setLayout(null);
		
		P_Init = new InitPanel(this);
		
		this.add(P_Init);
	}
	
	public void addMainGamePanel() throws SQLException {
		P_MainGame = new MainGamePanel();
		P_MainGame.setBounds(0,0,1440,900);
		this.add(P_MainGame);
	}
	
	public void addEndingPanel() {
		P_Ending = new EndingPanel();
		P_Ending.setBounds(0, 0, 1440, 900);
		this.add(P_Ending);
	}
	public void addExplainPanel() throws SQLException{
		P_Explain = new ExplainPanel();
		P_Explain.setBounds(0, 0, 1440, 900);
		this.add(P_Explain);
	}
	public void enableInitPanel() {
		this.P_Init.setVisible(true);
	}
	
	public MainGamePanel getMainGamePanel() {
		return this.P_MainGame;
	}
	public void disableInitPanel() {
		this.P_Init.setVisible(false);
	}
	
	public void disableEndingPanel() {
		this.P_Ending.setVisible(false);
	}
	public void disableExplainPanel() {
		this.P_Explain.setVisible(false);
	}
	public InitPanel getInitPanel() {
		return P_Init;
	}
	
	public void setnRank(String nRank) {
		this.nRank=nRank;
	}
	public void setnSex(String nSex) {
		this.nSex=nSex;
	}
	
	
	
	
	
	
	
}
