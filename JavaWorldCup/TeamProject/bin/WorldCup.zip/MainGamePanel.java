import javax.swing.*;
import java.awt.*;

public class MainGamePanel extends JPanel {
	private EntryPanel leftPanel,rightPanel;
	private JButton btnH;
	
}
